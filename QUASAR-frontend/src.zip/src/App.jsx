import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import LandingPage from './components/LandingPage';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import ForgotPassword from './components/auth/ForgotPassword';
import CompleteProfile from './components/auth/CompleteProfile';
import Onboarding from './components/auth/Onboarding';
import Dashboard from './components/Dashboard';
import ProfilePage from './components/profile/ProfilePage';
import CreateProject from './components/projects/CreateProject';
import ProjectPage from './components/project/ProjectPage';
import InviteMembers from './components/project/InviteMembers';
import StudentDiscovery from './components/discovery/StudentDiscovery';
import ProjectDiscovery from './components/discovery/ProjectDiscovery';
import SkillDiscovery from './components/discovery/SkillDiscovery';
import RecommendedProjectsPage from './components/discovery/RecommendedProjectsPage';
import MyProjects from './components/projects/MyProjects';
import OAuth2RedirectHandler from './components/auth/OAuth2RedirectHandler';
import { RequestProvider } from './contexts/RequestContext';
import RequestsPage from './components/requests/RequestsPage';
import EventsPage from './components/events/EventsPage';
import EventDetailPage from './components/events/EventDetailPage';
import AdminDashboardLayout from './components/admin/AdminDashboardLayout';
import AdminOverview from './components/admin/AdminOverview';
import AdminEvents from './components/admin/AdminEvents';
import AdminEventDetails from './components/admin/AdminEventDetails';
import AdminUsers from './components/admin/AdminUsers';
import AdminProjects from './components/admin/AdminProjects';
import AdminMentors from './components/admin/AdminMentors';
import AdminRoute from './components/admin/AdminRoute';
import MeetingRoomsPage from '../src/components/project/MeetingRoomsPage';
import SkillMastery from './components/profile/SkillMastery';
import GlobalErrorManager from './components/GlobalErrorManager';
import ServerError from './components/common/ServerError';
import NotFound from './components/common/NotFound';

import MentorRoute from './components/mentor/MentorRoute';
import MentorDashboardLayout from './components/mentor/MentorDashboardLayout';
import MentorOverview from './components/mentor/MentorOverview';
import MentorStudents from './components/mentor/MentorStudents';
import MentorProjects from './components/mentor/MentorProjects';

import { Toaster } from '@/components/ui/sonner';
import AnimatedBackground from './components/common/AnimatedBackground';




function App() {
  return (
    <Router>
      <AuthProvider>
        <RequestProvider>
          <div className="App" style={{ position: 'relative', minHeight: '100vh' }}>
            <AnimatedBackground />
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/auth/oauth2/redirect" element={<OAuth2RedirectHandler />} />
              <Route
                path="/complete-profile"
                element={
                  <ProtectedRoute>
                    <CompleteProfile />
                  </ProtectedRoute>
                }
              />

              {/* Protected Routes */}
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <ProfilePage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/projects/create"
                element={
                  <ProtectedRoute>
                    <CreateProject />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/projects/:projectId"
                element={
                  <ProtectedRoute>
                    <ProjectPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/projects/:projectId/invite"
                element={
                  <ProtectedRoute>
                    <InviteMembers />
                  </ProtectedRoute>
                }
              />
              <Route path="/projects/:projectId/rooms" element={<MeetingRoomsPage />} />
              <Route
                path="/discover/students"
                element={
                  <ProtectedRoute>
                    <StudentDiscovery />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/discover/projects"
                element={
                  <ProtectedRoute>
                    <ProjectDiscovery />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/discover/skills"
                element={
                  <ProtectedRoute>
                    <SkillDiscovery />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/discover/recommendations"
                element={
                  <ProtectedRoute>
                    <RecommendedProjectsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/requests"
                element={
                  <ProtectedRoute>
                    <RequestsPage />
                  </ProtectedRoute>
                }
              />

              {/* New Routes for Dashboard functionality */}
              <Route
                path="/projects/my-projects"
                element={
                  <ProtectedRoute>
                    <MyProjects />
                  </ProtectedRoute>
                }
              />

              {/* Admin Routes */}
              <Route path="/admin" element={<AdminRoute><AdminDashboardLayout /></AdminRoute>}>
                <Route index element={<Navigate to="overview" replace />} />
                <Route path="overview" element={<AdminOverview />} />
                <Route path="events" element={<AdminEvents />} />
                <Route path="events/:eventId" element={<AdminEventDetails />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="projects" element={<AdminProjects />} />
                <Route path="mentors" element={<AdminMentors />} />
              </Route>

              {/* Mentor Routes */}
              <Route path="/mentor" element={<MentorRoute><MentorDashboardLayout /></MentorRoute>}>
                <Route index element={<Navigate to="overview" replace />} />
                <Route path="overview" element={<MentorOverview />} />
                <Route path="students" element={<MentorStudents />} />
                <Route path="projects" element={<MentorProjects />} />
              </Route>

              <Route
                path="/events"
                element={
                  <ProtectedRoute>
                    <EventsPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/events/:eventId"
                element={
                  <ProtectedRoute>
                    <EventDetailPage />
                  </ProtectedRoute>
                }
              />

              <Route
                path="/skills"
                element={
                  <ProtectedRoute>
                    <SkillMastery />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/onboarding"
                element={
                  <ProtectedRoute>
                    <Onboarding />
                  </ProtectedRoute>
                }
              />

              {/* Error Routes */}
              <Route path="/server-error" element={<ServerError />} />

              {/* Redirect any unknown routes to 404 */}
              <Route path="*" element={<NotFound />} />
            </Routes>
            <GlobalErrorManager />
            <Toaster richColors position="top-center" closeButton />
          </div>
        </RequestProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
