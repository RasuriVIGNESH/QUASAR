import apiService from './api.js';

class SkillsService {

    // ===== NEW METHOD FOR STATIC DATA =====
    // Get static predefined skills list - Matches /api/static-data/predefined-skills
    async getStaticPredefinedSkills() {
        try {
            // Updated to match the specified endpoint: /api/skills/predefined
            const response = await apiService.get('/skills/predefined');
            const rawData = response?.data || response || {};

            // Handle the backend's object (Map) response: { "SkillName": "CategoryName" }
            if (rawData && typeof rawData === 'object' && !Array.isArray(rawData)) {
                const formatted = Object.entries(rawData).map(([name, category]) => ({
                    name,
                    category
                }));
                return { data: formatted, success: true };
            }

            return response;
        } catch (error) {
            console.error('SkillsService: Error getting static predefined skills:', error);
            // Return empty array on failure so components don't crash
            return { data: [], success: false };
        }
    }

    // Alias for getStaticPredefinedSkills to maintain compatibility
    async getPredefinedSkills() {
        return this.getStaticPredefinedSkills();
    }

    // Get all skills with pagination - matches SkillController endpoint
    async getAllSkills(page = 0, size = 10, sortBy = 'name', sortDir = 'asc') {
        try {
            console.log('SkillsService: Getting all skills...');
            const params = { page, size, sortBy, sortDir };
            const response = await apiService.get('/skills', params);
            console.log('SkillsService: All skills response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error getting all skills:', error);
            throw new Error(error.message || 'Failed to get all skills');
        }
    }

    // Get skill categories - FIXED method name to reflect what it actually does
    async getSkillCategories() {
        try {
            console.log('SkillsService: Getting skill categories...');
            const response = await apiService.get('/skills/categories');
            console.log('SkillsService: Skill categories response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error getting skill categories:', error);
            throw new Error(error.message || 'Failed to get skill categories');
        }
    }

    // Get skills by category - matches SkillController endpoint
    async getSkillsByCategory(category, page = 0, size = 10) {
        try {
            console.log('SkillsService: Getting skills by category:', category);
            const params = { page, size };
            const response = await apiService.get(`/skills/category/${category}`, params);
            console.log('SkillsService: Skills by category response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error getting skills by category:', error);
            throw new Error(error.message || 'Failed to get skills by category');
        }
    }

    // Get popular skills - matches SkillController endpoint
    async getPopularSkills(page = 0, size = 10, options = {}) {
        try {
            console.log('SkillsService: Getting popular skills...');
            const params = { page, size };
            const response = await apiService.get('/popularSkills', params, options);
            console.log('SkillsService: Popular skills response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error getting popular skills:', error);
            throw new Error(error.message || 'Failed to get popular skills');
        }
    }

    // Search skills - FIXED parameter name to match SkillController
    async searchSkills(searchTerm, page = 0, size = 10) {
        try {
            console.log('SkillsService: Searching skills with term:', searchTerm);
            if (!searchTerm || searchTerm.trim().length === 0) {
                return { data: { content: [] } };
            }

            // FIXED: Use 'query' parameter instead of 'q' to match SkillController
            const params = { query: searchTerm.trim(), page, size };
            const response = await apiService.get('/skills/search', params);
            console.log('SkillsService: Search skills response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error searching skills:', error);
            throw new Error(error.message || 'Failed to search skills');
        }
    }

    // Create new skill - matches SkillController endpoint
    async createSkill(skillData) {
        try {
            console.log('SkillsService: Creating new skill with data:', skillData);
            if (!skillData.name || !skillData.category) {
                throw new Error('Skill name and category are required');
            }

            const response = await apiService.post('/skills', skillData);
            console.log('SkillsService: Create skill response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error creating skill:', error);
            throw new Error(error.message || 'Failed to create skill');
        }
    }

    // Update skill - matches SkillController endpoint
    async updateSkill(skillId, skillData) {
        try {
            console.log('SkillsService: Updating skill:', skillId, 'with data:', skillData);
            if (!skillId) {
                throw new Error('Skill ID is required for update');
            }
            if (!skillData.name || !skillData.category) {
                throw new Error('Skill name and category are required');
            }

            const response = await apiService.put(`/skills/${skillId}`, skillData);
            console.log('SkillsService: Update skill response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error updating skill:', error);
            throw new Error(error.message || 'Failed to update skill');
        }
    }

    // Delete skill - matches SkillController endpoint
    async deleteSkill(skillId) {
        try {
            console.log('SkillsService: Deleting skill:', skillId);
            if (!skillId) {
                throw new Error('Skill ID is required for deletion');
            }

            const response = await apiService.delete(`/skills/${skillId}`);
            console.log('SkillsService: Delete skill response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error deleting skill:', error);
            throw new Error(error.message || 'Failed to delete skill');
        }
    }
    async getUserSkillsByUserId(userId) {
        try {
            console.log('SkillsService: Fetching user skills from new endpoint for userId:', userId);
            if (!userId) {
                throw new Error('User ID is required');
            }

            const response = await apiService.get(`/students/users/${userId}/skills`);
            console.log('SkillsService: User skills response:', response);

            // Handle both direct array responses and wrapped responses
            // Usually, if the endpoint is /users/{id}/skills, it returns the list directly
            const skillsData = response?.data || response || [];

            return {
                data: Array.isArray(skillsData) ? skillsData : (skillsData.content || []),
                success: true
            };
        } catch (error) {
            console.error('SkillsService: Error getting user skills:', error);
            return { data: [], success: false, error: error.message };
        }
    }

    // Add user skill - matches UserController endpoint and request format
    async addUserSkill(skillData, currentUser) {
        try {
            console.log('SkillsService: Adding user skill with data:', skillData);

            // Validate required fields
            if (!skillData.skillName) {
                throw new Error('Skill name is required');
            }

            // Map frontend data to backend AddUserSkillRequest format
            // Flattened structure based on validation error feedback
            const requestData = {
                skillName: skillData.skillName,
                category: skillData.category || skillData.skill?.category || '',
                level: skillData.level || 'BEGINNER',
                experience: String(skillData.experience || skillData.notes || '0'),
                currentUser: currentUser
            };

            console.log('SkillsService: Sending request data:', requestData);
            const response = await apiService.post('/skills', requestData);
            console.log('SkillsService: Add skill response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error adding skill:', error);
            throw new Error(error.message || 'Failed to add skill');
        }
    }

    // Add batch skills - matches new endpoint
    async addBatchSkills(skillsList, currentUser) {
        try {
            console.log('SkillsService: Adding batch skills:', skillsList.length);

            if (!skillsList || skillsList.length === 0) {
                return;
            }

            const skillsPayload = skillsList.map(s => ({
                skillName: s.skillName || s.skill?.name || s.name,
                level: s.level || 'BEGINNER',
                experience: String(s.experience || '0'),
                category: s.category || s.skill?.category || ''
            }));

            const payload = {
                skills: skillsPayload
            };

            console.log('SkillsService: Sending batch request:', payload);
            const response = await apiService.post('/skills/batch', payload);
            console.log('SkillsService: Batch add response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error adding batch skills:', error);
            throw new Error(error.message || 'Failed to add batch skills');
        }
    }

    // Update user skill - matches UserController endpoint and request format
    async updateUserSkill(skillId, skillData) {
        try {
            console.log('SkillsService: Updating user skill:', skillId, 'with data:', skillData);
            if (!skillId) {
                throw new Error('Skill ID is required for update');
            }

            // Map frontend data to backend UpdateUserSkillRequest format
            const requestData = {
                level: skillData.level || 'BEGINNER',
                experience: skillData.experience || skillData.notes || ''
            };

            console.log('SkillsService: Sending update request data:', requestData);
            const response = await apiService.put(`/skills/${skillId}`, requestData);
            console.log('SkillsService: Update user skill response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error updating user skill:', error);
            throw new Error(error.message || 'Failed to update user skill');
        }
    }

    // Delete user skill - matches UserController endpoint
    async deleteUserSkill(skillId) {
        try {
            console.log('SkillsService: Deleting user skill:', skillId);
            if (!skillId) {
                throw new Error('Skill ID is required for deletion');
            }

            const response = await apiService.delete(`/skills/${skillId}`);
            console.log('SkillsService: Delete user skill response:', response);
            return response;
        } catch (error) {
            console.error('SkillsService: Error deleting user skill:', error);
            throw new Error(error.message || 'Failed to delete user skill');
        }
    }
}

export const skillsService = new SkillsService();
export default skillsService;