package com.ADP.peerConnect.model.entity;

import com.ADP.peerConnect.model.enums.SkillLevel;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Table(name = "user_skills", indexes = {
        @Index(name = "idx_user_skill_user", columnList = "user_id"),
        @Index(name = "idx_user_skill_skill", columnList = "skill_id"),
        @Index(name = "idx_user_skill_level", columnList = "level")
}, uniqueConstraints = {
        @UniqueConstraint(name = "uk_user_skill", columnNames = { "user_id", "skill_id" })
})
public class UserSkill {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_skill_seq")
    @SequenceGenerator(
            name = "user_skill_seq",
            sequenceName = "user_skills_id_seq",
            allocationSize = 1
    )
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @NotNull(message = "User is required")
    @JsonBackReference
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "skill_id", nullable = false)
    @NotNull(message = "Skill is required")
    private Skill skill;

    @Enumerated(EnumType.STRING)
    @Column(name = "level", nullable = false)
    @NotNull(message = "Skill level is required")
    private SkillLevel level;

    @Column(name = "experience", columnDefinition = "TEXT")
    @Size(max = 500, message = "Experience description must not exceed 500 characters")
    private String experience;


    public UserSkill(User user, Skill skill, SkillLevel level) {
        this.user = user;
        this.skill = skill;
        this.level = level;
    }

    public UserSkill(User user, Skill skill, SkillLevel level, String experience) {
        this(user, skill, level);
        this.experience = experience;
    }
}