package com.ADP.peerConnect.model.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class MentorResponse {
    private String id;
    private String email;
    private String firstName;
    private String lastName;
    private String bio;
    private String branch;
    private String department;
    private String designation;
}
